# Explore Ireland – Fixed Hover Edition

This version includes corrected polygon behaviour, hover highlighting, and full pan/zoom without blocking.
