# Explore Ireland – Real Counties, Full UI

This project now uses real, simplified boundaries for all 32 counties on the island of Ireland,
derived from GADM v4.1 (level 1 dissolved from level 2), simplified for web use.

Features:
- Dark-mode Leaflet map
- Real county geometries
- County outlines by default
- Hover highlight in county colours with tooltip
- Click-through county detail page
- Province quick-zoom buttons (Ulster, Connacht, Leinster, Munster)
- Map style toggle: outlines vs county colours
- Overlay toggle: political vs (future) cultural vs geographic-only
- Touch-friendly behaviour on mobile
