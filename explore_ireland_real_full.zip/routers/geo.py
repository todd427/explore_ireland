from fastapi import APIRouter, Request

router = APIRouter()

@router.get("/me")
async def my_location(request: Request):
    ip = request.client.host
    # Real GeoIP can be wired in later
    return {"ip": ip, "guessed_county": None, "confidence": 0.0}
